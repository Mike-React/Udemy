import React from 'react';

class NotFound extends React.Component {
    render () {
        return(
            <div>
                Error 404 Page not found!!!
            </div>
        );
    }
}

export default NotFound;