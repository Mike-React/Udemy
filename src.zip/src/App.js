import React from 'react';
import Main from './Main';
import Admin from './Admin';
import NotFound from './NotFound';
import { Link, BrowserRouter, Route, Switch } from 'react-router-dom';


class App extends React.Component {
  render () {
    return(
      <div>
        <BrowserRouter>
          <Link to="/admin">Admin</Link>
          <Switch>
            <Route path="/" exact component={Main} />
            <Route path="/admin" component={Admin} />
            <Route component={NotFound} />
          </Switch>
        </BrowserRouter>
			</div>
      
    );
  }
}

export default App;
