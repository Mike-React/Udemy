import React from 'react';
import ReactPlayer from 'react-player';
import Truncate from 'react-truncate';
import { UncontrolledTooltip } from 'reactstrap';
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';
import { Link } from 'react-router-dom';
import "./Main.css";
//import { ServerResponse } from 'http';
import LogIn from './LogIn';
import SignUp from './SignUp';
import Course from './Course';

//import { Row, Col, Card, Button, CardImg, CardTitle, CardText, CardDeck, CardSubtitle, CardBody } from 'reactstrap';


import SplitterLayout from 'react-splitter-layout';
import 'react-splitter-layout/lib/index.css';


class Main extends React.Component {
  state = {
    courses: [],
    categoryCourses: [],
    categories: [],
    //videos: [],
    Name: '',
    AvatarURL: '',
    Comment: '',
    responsive: {
      superLargeDesktop: {
        // the naming can be any, depends on you.
        breakpoint: { max: 4000, min: 3000 },
        items: 5,
      },
      desktop: {
        breakpoint: { max: 3000, min: 1024 },
        items: 5,
      },
      tablet: {
        breakpoint: { max: 1024, min: 464 },
        items: 2,
      },
      mobile: {
        breakpoint: { max: 464, min: 0 },
        items: 1,
      },
    }
  };

  componentDidMount() {
    fetch('http://localhost:3001/getcourses')
      .then(response => response.json())
      .then(courses => (this.setState({courses})));
    
    fetch('http://localhost:3001/getcategorycourses', {
        method: 'POST',
        headers : {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify({
            Category: 1
        })
    })
    .then(response => response.json())
    .then(categoryCourses => (this.setState({categoryCourses})));

    fetch('http://localhost:3001/getcategories')
      .then(response => response.json())
      .then(categories => (this.setState({categories})));

    /*
      fetch('http://localhost:3001/getvideos')
      .then(response => response.json())
      .then(videos => (this.setState({videos})));
    */
  }

  handleNameChange = (e) => {
    this.setState({Name: e.target.value});
  }

  handleAvatarURLChange = (e) => {
    this.setState({AvatarURL: e.target.value});
  }

  handleCommentChange = (e) => {
    this.setState({Comment: e.target.value});
  }

  addComment = () => {
    fetch('http://localhost:3001/postcomment', {
      method: 'POST',
      headers : {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
       },
      body: JSON.stringify({
        Name: this.state.Name,
        AvatarURL: this.state.AvatarURL,
        Comment: this.state.Comment
      })
    });
    //.then(response => response.json())
    //.then(ServerResponse => console.warn(ServerResponse))
  }

  handleCategory = (id) => {
    fetch('http://localhost:3001/getcategorycourses', {
        method: 'POST',
        headers : {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify({
            Category: id
        })
    })
    .then(response => response.json())
    .then(categoryCourses => (this.setState({categoryCourses})));
  }


  render() {
    return (
      <div>
        <div class="ui borderless centered grid menu">
          <a class="item"><img src='https://www.udemy.com/staticx/udemy/images/v6/logo-coral.svg' alt="Udemy" width="110" height="32" /></a>
          <a class="item"><i class="th icon"></i>Categories</a>
          <a class="item">
            <div class="ui icon input">
              <input type="text" placeholder='Search for anything' />
              <i class="search icon"></i>
            </div>
          </a>
          <a class="item">
            <div class="ui basic button" id="udemyForBusinessBtn" data-tooltip="Get your team access to 3,500+ top Udemy courses anytime, anywhere" data-position="bottom right">
              Udemy for Business
            </div>
          </a>
          <a class="item">
            <div class="ui basic button" id="teachOnUdemyBtn" data-tooltip="Turn what you know into an opportunity and reach millions around the world." data-position="bottom right">
              Teach on Udemy
            </div>
          </a>
          <a class="item">
            <button class="circular ui icon basic button" id="cartBtn">
            <i class="shop icon"></i>
            </button>
          </a>
          <a class="item"><LogIn /></a>
          <a class="item"><SignUp /></a>
        </div>
        

        <div className='revolution_slider'>
            <div className='slider_header'>More than a course</div>
            <div className='slider_text'>Join the learning movement. Courses from A$12.99 ends tomorrow, 11:59 p.m. PDT.</div>
            <div class="ui big icon input">
              <input type="text" placeholder="What do you want to learn?" />
              <i class="search icon"></i>
            </div>
        </div>

        <ul>
          {/*this.state.courses.map(course => <li>
            <h2>{course.CourseName}</h2>
            <img src={course.ImageURL} alt={course.CourseName} />
            <p>{course.Description}</p>
            <p>${course.Price}</p>
          </li>)*/}
        </ul>
        
        {/*this.state.courses.map(course => 
          <Card cardImg={course.ImageURL} courseName={course.CourseName} author='author' ratings='ratings' price={course.Price} />
        )*/}


        
        
        <div class="container-fluid" id="container">
            <div class="row align-items-center">
                <div class="col-lg-3" id="textContainer">
                    <h3>The world’s largest selection of courses</h3>
                    <p>Choose from over 100,000 online video courses with new additions published every month</p>
                </div>
                <div class="col-lg-9">
                    <div class="ui borderless grid menu" id="categoryMenu">
                        {this.state.categories.map(category => <a class="item"><button class="ui basic button" id="categoryBtn" onClick={() => {this.handleCategory(category.CategoryID)}}>{category.CategoryName}</button></a>)}
                    </div>
                    <div class='ui cards'>
                        {this.state.categoryCourses.map(categoryCourse => <div class='ui card' id={"c" + categoryCourse.CourseID}>
                            <div class='image'>
                                <img src={categoryCourse.ImageURL} alt={categoryCourse.CourseName} />
                            </div>
                            <div class='content'>
                                <p class='header'><Truncate lines={2} ellipsis='...'>{categoryCourse.CourseName}</Truncate></p>
                            <div class="meta">
                                <span class="date">author</span>
                            </div>
                            <div class="description">
                                ratings
                                <br />
                                A${categoryCourse.Price}
                            </div>
                            </div>
                            <div>
                                <UncontrolledTooltip placement="right" target={"c" + categoryCourse.CourseID} autohide={false} id="toolTip">
                                    <Course courseName={categoryCourse.CourseName} courseDescription={categoryCourse.Description} />
                                </UncontrolledTooltip>
                            </div>
                        </div>)}
                    </div>
                </div>
            </div>
        </div>


        <br />
        <h3 class="ui header" style={{marginLeft: 70}}>Students are viewing</h3>

        {/*
        <AliceCarousel
          items={this.state.courses.map(course => <div class='ui card' id={"s" + course.CourseID}>
            <div class='image'>
                <img src={course.ImageURL} alt={course.CourseName} />
            </div>
            <div class='content'>
                <p class='header'><Truncate lines={2} ellipsis='...'>{course.CourseName}</Truncate></p>
            <div class="meta">
                <span class="date">author</span>
            </div>
            <div class="description">
                ratings
                <br />
                A${course.Price}
            </div>
            </div>
            <div>
                <UncontrolledTooltip placement="right" target={"s" + course.CourseID} autohide={false} id="toolTip">
                  <Course courseName={course.CourseName} courseDescription={course.Description} />
                </UncontrolledTooltip>
            </div>
          </div>)}
          responsive={{0: { items: 1 }, 464: { items: 3 }, 1024: { items: 5 }}}
          autoPlayInterval={3000}
          autoPlayDirection="ltr"
          autoPlay={true}
          infinite={false}
          fadeOutAnimation={true}
          disableAutoPlayOnAction={true}
          swipeDisabled={false}
          buttonsDisabled={true}
          stagePadding={{paddingLeft: 70}}
        />
        */}




        <Carousel
          swipeable={false}
          draggable={false}
          responsive={this.state.responsive}
          ssr={true} // means to render carousel on server-side.
          infinite={true}
          autoPlay={this.props.deviceType !== "mobile" ? true : false}
          autoPlaySpeed={3000}
          keyBoardControl={false}
          transitionDuration={500}
          removeArrowOnDeviceType={["tablet", "mobile"]}
          deviceType={this.props.deviceType}
          slidesToSlide={5}
          centerMode={true}
        >
          {this.state.courses.map(course => <div class='ui card item' id={"d" + course.CourseID}>
              <div class='image'>
                  <img src={course.ImageURL} alt={course.CourseName} />
              </div>
              <div class='content'>
                  <p class='header'><Truncate lines={2} ellipsis='...'>{course.CourseName}</Truncate></p>
              <div class="meta">
                  <span class="date">author</span>
              </div>
              <div class="description">
                  ratings
                  <br />
                  A${course.Price}
              </div>
              </div>
              <div>
              </div>
            </div>)}
        </Carousel>
        <br />


        <div className='recommendation_slider'>
            <div className='recommendation_header'>Get personalized recommendations</div>
            <div className='recommendation_text'>Answer a few questions for your top picks</div>
            <button class="negative ui button">
              Get started
            </button>
        </div>


        <br />
        <h2 class="ui header" style={{marginLeft: 70}}>Top categories</h2>
        <div class="ui four column grid topCategories">
          <div class="row">
            <div class="column"><button class="fluid ui basic button">Development</button></div>
            <div class="column"><button class="fluid ui basic button">Business</button></div>
            <div class="column"><button class="fluid ui basic button">IT and Software</button></div>
            <div class="column"><button class="fluid ui basic button">Design</button></div>
          </div>
          <div class="row">
            <div class="column"><button class="fluid ui basic button">Marketing</button></div>
            <div class="column"><button class="fluid ui basic button">Personal Development</button></div>
            <div class="column"><button class="fluid ui basic button">Photography</button></div>
            <div class="column"><button class="fluid ui basic button">Music</button></div>
          </div>
        </div>


        

        <div style={{backgroundColor: '#f7f8fa', marginTop: 30, paddingTop: 30}}>
          <h2 class="ui header" style={{marginLeft: 70}}>What our students have to say</h2>
          <div class='ui three centered cards' id="reviewContainer">
            <div class="ui card">
            <div class="content" style={{fontSize: 16}}>
                <img class="ui circular tiny image" alt="Borivoje" src="https://i.udemycdn.com/user/100x100/8872940_27b4_3.jpg" />
                <span style={{paddingLeft: 15, fontWeight: 600}}>Borivoje</span>
                <br />
                <br />
                <p style={{fontSize: 16}}>Udemy is a life saver. I don't have the time or money for a college education. My goal is to become a freelance web developer, and thanks to Udemy, I'm really close.</p>
              </div>
            </div>
            <div class="ui card">
            <div class="content" style={{fontSize: 16}}>
                <img class="ui circular tiny image" alt="Dipesh" src="https://i.udemycdn.com/user/100x100/22869844_edad.jpg" />
                <span style={{paddingLeft: 15, fontWeight: 600}}>Dipesh</span>
                <br />
                <br />
                <p style={{fontSize: 16}}>I believe in lifelong learning and Udemy is a great place to learn from experts. I've learned a lot and recommend it to all my friends.</p>
              </div>
            </div>
            <div class="ui card">
              <div class="content" style={{fontSize: 16}}>
                <img class="ui circular tiny image" alt="Zulaika" src="https://i.udemycdn.com/user/100x100/26154780_76c8.jpg" />
                <span style={{paddingLeft: 15, fontWeight: 600}}>Zulaika</span>
                <br />
                <br />
                <p style={{fontSize: 16}}>I work in project management and joined Udemy because I get great courses for less. The instructors are fantastic, interesting, and helpful. I plan to use Udemy for a long time!</p>
              </div>
            </div>
          </div>



          <br />
          <br />



          <p style={{textAlign: 'center'}}>Trusted by companies of all sizes</p>
          <br />
          <div class="ui six column grid trustedCompanies">
            <div class="row">
              <div class="column"><img src="https://i.udemycdn.com/partner-logos/booking-logo.svg" alt="booking" width="151" height="26" /></div>
              <div class="column"><img src="https://i.udemycdn.com/partner-logos/volkswagen-logo.svg" alt="volkswagen" width="32" height="32" /></div>
              <div class="column"><img src="https://i.udemycdn.com/partner-logos/mercedes-logo.svg" alt="mercedes" width="118" height="28" /></div>
              <div class="column"><img src="https://i.udemycdn.com/partner-logos/pinterest-logo.svg" alt="pinterest" width="115" height="28" /></div>
              <div class="column"><img src="https://i.udemycdn.com/partner-logos/adidas-logo.svg" alt="adidas" width="47" height="32" /></div>
              <div class="column"><img src="https://i.udemycdn.com/partner-logos/eventbrite-logo.svg" alt="eventbrite" width="115" height="32" /></div>
            </div>
          </div>


          <br />


          



          {/*
          <SplitterLayout>
            <div class="column" style={{textAlign: 'center', marginTop: 50}}>
              <span className="splitterHeader">Teach on Udemy</span>
              <p className="splitterContent">Teach what you love. Udemy gives you the tools to create an online course.</p>
              <button class="negative ui button">
                Start teaching
              </button>
            </div>
            <div class="column" style={{textAlign: 'center', marginTop: 50}}>
              <span className="splitterHeader">Udemy for Business</span>
              <p className="splitterContent">Get unlimited access to 3,500+ of Udemy’s top courses for your team.</p>
              <button class="negative ui button">
                Get Udemy for Business
              </button>
            </div>
          </SplitterLayout>
          */}


          <div class="container-fluid">
            <div class="row">
              <div class="col-6" style={{textAlign: 'center', padding: '30px 0'}}>
                <span className="splitterHeader">Teach on Udemy</span>
                <p className="splitterContent">Teach what you love. Udemy gives you the tools to create an online course.</p>
                <button class="negative ui button">
                  Start teaching
                </button>
              </div>
              <div class="col-6" style={{textAlign: 'center', padding: '30px 0', borderLeft: '1px solid grey'}}>
                <span className="splitterHeader">Udemy for Business</span>
                <p className="splitterContent">Get unlimited access to 3,500+ of Udemy’s top courses for your team.</p>
                <button class="negative ui button">
                  Get Udemy for Business
                </button>
              </div>
            </div>
          </div>
          <br />
          
          


        </div>


        


        <div class="container-fluid">
          <div class="row justify-content-around">
            <div class="col-2" style={{padding: '30px 0'}}>
              <p className="footerItemBold">Udemy for Business</p>
              <p className="footerItemBold">Teach on Udemy</p>
              <p className="footerItem">Udemy app</p>
              <p className="footerItem">About us</p>
            </div>
            <div class="col-2" style={{padding: '30px 0'}}>
              <p className="footerItem">Careers</p>
              <p className="footerItem">Blog</p>
              <p className="footerItem">Help and Support</p>
              <p className="footerItem">Affiliate</p>
            </div>
            <div class="col-2" style={{padding: '30px 0'}}>
              <p className="footerItem">Sitemap</p>
              <p className="footerItem">Popular courses</p>
            </div>
            <div class="col-2" style={{padding: '30px 0'}}>
              <p className="footerItem">English</p>
            </div>
          </div>
        </div>


        <div class="container-fluid" style={{backgroundColor: '#f7f8fa'}}>
          <div class="row align-items-center justify-content-between" style={{height: 100}}>
            <div class="col-4" style={{marginLeft: 70}}>
              <img alt="Udemy" class="ufb-logo" src="https://www.udemy.com/staticx/udemy/images/v6/logo-coral.svg" width="110" height="32" />
              <span style={{paddingLeft: 20}}>Copyright © 2019 Udemy, Inc.</span>
            </div>
            <div class="col-4">
              <span>Terms</span>
              <span style={{paddingLeft: 20}}>Privacy Policy and Cookie Policy</span>
            </div>
          </div>
        </div>


        
        

        


        {/*
        <div class='ui cards'>
          {this.state.courses.map(course => <div class='ui card' id={"c" + course.CourseID}>
            <div class='image'>
              <img src={course.ImageURL} alt={course.CourseName} />
            </div>
            <div class='content'>
              <p class='header'>{course.CourseName}</p>
              <div class="meta">
                <span class="date">author</span>
              </div>
              <div class="description">
                ratings
                <br />
                A${course.Price}
              </div>
            </div>
            <div>
              <UncontrolledTooltip placement="right" target={"c" + course.CourseID} autohide={false} id="toolTip">
                <Course courseName={course.CourseName} courseDescription={course.Description} />
              </UncontrolledTooltip>
            </div>
          </div>)}
        </div>
        */}


        <ul>
          {/*this.state.videos.map(video => <li>
            <ReactPlayer url={video.VideoURL} controls={true} />
          </li>)*/}
        </ul>

        {/*
        <input type='text' placeholder='Enter your name here...' onChange={this.handleNameChange} />
        <br />
        <input type='text' placeholder='Enter your avatar link here...' onChange={this.handleAvatarURLChange} />
        <br />
        <textarea placeholder='Enter your comment here...' onChange={this.handleCommentChange} />
        <br />
        <button onClick={this.addComment}>Submit</button>
        */}


        
        
      </div>
    );
  }
}

export default Main;
