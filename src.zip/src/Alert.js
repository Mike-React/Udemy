import React from 'react';
import './Alert.css';

class Alert extends React.Component {
    render() {
        return (
            <div class="ui mini red message" id='alert'>{this.props.message}</div>
        );
    }
}

export default Alert;