import React from 'react';
import Popup from "reactjs-popup";
import './SignUp.css';

class SignUp extends React.Component {
    signup = () => {
        fetch('http://localhost:3001/signup', {
            method: 'POST',
            headers : {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                UserName: document.getElementById('fullName').value,
                Email: document.getElementById('email').value,
                Password: document.getElementById('password').value,
            })
        });
        //.then(response => response.json())
        //.then(ServerResponse => console.warn(ServerResponse))
    }

    render() {
        return (
            <Popup contentStyle={{width: '20%'}}
            trigger={<button class="negative ui button" onClick={this.toggleSignUp}>Sign Up</button>}
            modal
            closeOnDocumentClick={false}
            lockScroll
            >
                {close => (<div className='signUpContainer'>
                    <div class="ui form">
                        <h4 class="ui dividing header">
                            <div className='signUpHeader'>
                                Sign Up and Start Learning!
                                <button
                                    id="closeButton"
                                    class="huge ui icon right floated basic button"
                                    onClick={() => {
                                    close();
                                    }}
                                >
                                    <i class="x icon" />
                                </button>
                            </div>
                        </h4>
                        <div class="thirteen wide field ui left icon input">
                            <input type="text" id="fullName" placeholder="Full Name" />
                            <i class="user icon"></i>
                        </div>
                        <br />
                        <div class="thirteen wide field ui left icon input">
                            <input type="text" id="email" placeholder="Email" />
                            <i class="envelope icon"></i>
                        </div>
                        <br />
                        <div class="thirteen wide field ui left icon input">
                            <input type="password" id="password" placeholder="Password" />
                            <i class="lock icon"></i>
                        </div>
                        <br />
                        <button class="thirteen wide field negative ui button" onClick={this.signup}>Sign Up</button>
                    </div>
                </div>)}
            </Popup>
        );
    }
}

export default SignUp;