import React from 'react';
import Popup from "reactjs-popup";
import './LogIn.css';
import Alert from './Alert';

class LogIn extends React.Component {
    state = {
        user: [],
        alertMessage: ''
    }

    login = () => {
        fetch('http://localhost:3001/login', {
            method: 'POST',
            headers : {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                Email: document.getElementById('email').value,
                Password: document.getElementById('password').value
            })
        })
        .then(response => response.json())
        .then(user => (this.setState({user}, () => {
            if (this.state.user.length === 0) {
                this.setState({alertMessage: 'Please check your email and password.'});
            }
            else {
                console.log('Log in successfully!');
            }
        })));
    }

    render() {
        return (
            <Popup contentStyle={{width: '20%'}}
            trigger={<button class="positive ui button" onClick={this.toggleLogIn}>Log In</button>}
            modal
            closeOnDocumentClick={false}
            lockScroll
            >
                {close => (<div className='logInContainer'>
                    <div class="ui form">
                        <h4 class="ui dividing header">
                            <div className='logInHeader'>
                                Log In to Your Udemy Account!
                                <button
                                    id="closeButton"
                                    class="huge ui icon right floated basic button"
                                    onClick={() => {
                                        close();
                                        this.setState({alertMessage: ''});
                                    }}
                                >
                                    <i class="x icon" />
                                </button>
                            </div>
                        </h4>
                        <button class="thirteen wide field ui facebook button">
                            <i class="facebook icon"></i>
                            Continue with Facebook
                        </button>
                        <br />
                        <button class="thirteen wide field ui google button">
                            <i class="google icon"></i>
                            Continue with Google
                        </button>
                        <br />
                        {this.state.alertMessage.length!==0 ?
                            <Alert message={this.state.alertMessage} />: null
                        }
                        <div class="thirteen wide field ui left icon input">
                            <input type="text" id="email" placeholder="Email" />
                            <i class="envelope icon"></i>
                        </div>
                        <br />
                        <div class="thirteen wide field ui left icon input">
                            <input type="password" id="password" placeholder="Password" />
                            <i class="lock icon"></i>
                        </div>
                        <br />
                        <button class="thirteen wide field negative ui button" onClick={this.login}>Log In</button>
                    </div>
                </div>)}
            </Popup>
        )
    }
}

export default LogIn;