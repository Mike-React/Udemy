import React from 'react';

class Admin extends React.Component {
    state = {
        categories: [],
        selectedCategory: ''
    }

    submit = () => {
        fetch('http://localhost:3001/addcourse', {
            method: 'POST',
            headers : {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                CourseName: this.refs.CourseName.value,
                Price: this.refs.Price.value,
                ImageURL: this.refs.ImageURL.value,
                Description: this.refs.Description.value,
                CategoryID: this.refs.category.value
            })
        })
        .then(response => response.json());
    }

    componentDidMount = () => {
        fetch('http://localhost:3001/getcategories')
            .then(response => response.json())
            .then(categories => (this.setState({categories})));
    }

    render () {
        return(
            <div>
                <br />
                <div class="ui form">
                    <div class="six wide field ui input">
                        <input type="text" ref="CourseName" placeholder="Course Name" />
                    </div>
                    <br />
                    <div class="six wide field ui input">
                        <input type="text" ref="Price" placeholder="Price" />
                    </div>
                    <br />
                    <div class="six wide field ui input">
                        <input type="text" ref="ImageURL" placeholder="Image URL" />
                    </div>
                    <br />
                    <div class="six wide field ui input">
                        <input type="text" ref="Description" placeholder="Description" />
                    </div>
                    <br />
                    <div class="six wide field">
                        <select ref="category">
                            {this.state.categories.map(categorie => 
                                <option value={categorie.CategoryID}>{categorie.CategoryName}</option>)
                            }
                        </select>
                    </div>

                    <button class="ui positive button" onClick={this.submit}>Submit</button>
                </div>
                <br />
                <br />
                <br />
                <button class="ui negative button" onClick={()=>{this.props.history.push('/')}}>Back</button>
                
            </div>
        );
    }
}

export default Admin;