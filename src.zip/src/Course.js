import React from 'react';

class Course extends React.Component {
    render() {
        return (
            <div>
                Last updated: 09/2019
                <br />
                {this.props.courseName}
                <br />
                200 lectures 20 hours
                <br />
                {this.props.courseDescription}
                <ol>
                    <li>What you will learn 1</li>
                    <li>What you will learn 2</li>
                    <li>What you will learn 3</li>
                </ol>
                <button class="thirteen wide field negative ui button">Add to cart</button>
            </div>
        );
    }
}

export default Course;